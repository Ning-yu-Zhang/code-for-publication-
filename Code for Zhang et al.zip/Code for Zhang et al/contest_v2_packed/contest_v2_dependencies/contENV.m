function [epoly,emat] = contENV(cname,rota)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This function retrieves the polygon (vertices) of an environment when requested
%   It is really just more of a convenient storage area for the polygon creation etc
%   epoly = contENV(cname,rota)
%
%%%%%%%% Inputs
%   cname = the name of the required environment
%   rota = the rotation angle we want (clockwise)
%
%%%%%%%% Outputs
%   epoly = the environment vertices/coordinates
%
%%%%%%%% Comments
%   06/07/17 created 
%   � Roddy Grieves: rmgrieves@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Get environment polygon
%   cdiameter = 80; % diameter of circular arena for new OF 
cdiameter = 100; % diameter of circular arena - old circ 
cboxsize = 120; % length of context box side
nboxsize = 100;% length of new square box side 

% used for environment matrix map (we want odd side length values so the walls are in the center)
ediameter = 2*floor(cdiameter/2)+1;
eboxsize = 2*floor(cboxsize/2)+1;
eboxsize2 = 2*floor(nboxsize/2)+1;

if strcmp(cname,'cbox')
    % environment polygon
    v1 = cboxsize*0.42;
    c1 = .49;
    c2 = .51;
    epoly = [0 0; 0 cboxsize*c1; v1 cboxsize*c1; v1 cboxsize*c2; 0 cboxsize*c2; 0 cboxsize; cboxsize cboxsize; cboxsize cboxsize*c2; cboxsize-v1 cboxsize*c2; cboxsize-v1 cboxsize*c1; cboxsize cboxsize*c1; cboxsize 0; 0 0];

    % environment matrix map
    emat = padarray(ones(eboxsize-2,'logical'),[1 1],false,'both'); 
    emat(ceil(eboxsize/2)-1:ceil(eboxsize/2)+1,1:floor(v1)) = false;
    emat(ceil(eboxsize/2)-1:ceil(eboxsize/2)+1,end-floor(v1):end) = false;

elseif strcmp(cname,'square')
    epoly = [0 0; 0 nboxsize/2; 0 nboxsize; nboxsize nboxsize; nboxsize nboxsize/2; nboxsize 0; 0 0];
    
    % environment matrix map
    emat = padarray(ones(eboxsize2-2,'logical'),[1 1],false,'both'); 
    
elseif strcmp(cname,'circ')
    as = (1:5:360)';
    pnow = [cdiameter./2.*cos(as.*(pi/180)), cdiameter./2.*sin(as.*(pi/180))];
    pnow(any(isnan(pnow),2),:) = [];
    pnow = unique(pnow,'rows','stable');
    pnow = [pnow; pnow(1,:)];
    epoly = pnow;
    
    % environment matrix map
    emat = false(ediameter,ediameter);
    emat(ceil(ediameter/2),ceil(ediameter/2)) = true;
    bmat = bwdist(emat);
    emat(bmat>ediameter/2) = false;
    emat(bmat<=ediameter/2) = true;
    emat = padarray(emat,[1 1],false,'both');    

    
elseif strcmp(cname,'qbox')
    v1 = cboxsize*0.433;
    v2 = cboxsize*0.40;    
    c1 = .498;
    c2 = .502;
    epoly = [0 0; 0 cboxsize*c1; v1 cboxsize*c1; v1 cboxsize*c2; 0 cboxsize*c2; 0 cboxsize; cboxsize*c1 cboxsize;...
        cboxsize*c1 cboxsize-v2; cboxsize*c2 cboxsize-v2; cboxsize*c2 cboxsize; cboxsize cboxsize; cboxsize cboxsize*c2;...
        cboxsize-v1 cboxsize*c2; cboxsize-v1 cboxsize*c1; cboxsize cboxsize*c1; cboxsize 0;...
        cboxsize*c2 0; cboxsize*c2 v2; cboxsize*c1 v2; cboxsize*c1 0; 0 0];

%     figure
%     plot(epoly(:,1),epoly(:,2),'k')
%     daspect([1 1 1])    
    
    % environment matrix map
    emat = padarray(ones(eboxsize-2,'logical'),[1 1],false,'both'); 
    emat(ceil(eboxsize/2),1:floor(v1)) = false;
    emat(ceil(eboxsize/2),end-floor(v1):end) = false;
    emat(1:floor(v1),ceil(eboxsize/2)) = false;
    emat(end-floor(v1):end,ceil(eboxsize/2)) = false;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Perform rotation if necessary
if exist('rota','var') && rota~=0
    epoly2 = zeros(3,length(epoly(:,1)));
    
    % the center of rotation
    x_center = mean(epoly(:,1));
    y_center = mean(epoly(:,2));

    % define a rotation matrix
    theta = deg2rad(360-rota);
    R = [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];

    % define affine transformation for translation
    a = [1 0 x_center;0 1 y_center; 0 0 1];
    c = [1 0 -x_center;0 1 -y_center; 0 0 1];
    M = a*R*c;

    for i = 1:length(epoly(:,1))
        epoly2(:,i) = M*[epoly(i,1) epoly(i,2) 1]';
    end

    epoly = epoly2(1:2,:)';
    
    %% rotate emat
    emat = imrotate(emat,-(360-rota),'nearest','loose');
    emat(:,~logical(sum(emat,1))) = [];
    emat(~logical(sum(emat,2)),:) = [];
    emat = padarray(emat,[1 1],false,'both'); 

end



























