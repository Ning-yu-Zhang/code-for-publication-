function figCOMP1(pdata,sdata,fig_vis)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This function takes an sdata structure, a cell identifier and generates a figure for the context box experiment
%   figCOMP1(sdata,uci,fig_vis,save_fig)
%
%%%%%%%% Inputs
%   sdata = sdata structure from context box function
%   fig_vis = (optional), 'on' to show figures, 'off' to hide figures, default is 'off'
%   save_fig = (optional), 1 to save figures in .fig files, 0 otherwise, default is 0
%
%%%%%%%% Comments
%   04/07/17 created to contain all of this figure code
%   25/07/17 fixed scaling problem from variable pixel ratio
%   � Roddy Grieves: rmgrieves@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initial variables
    if ~exist('fig_vis','var') || isempty(fig_vis)
        fig_vis = 'off';
    end

    part_names = table2cell(pdata.part_config(:,2))'; % the names you want the outputs to be saved as, these cannot start with a number: i.e. 'session1'
    nparts = length(part_names);
    part_config = pdata.part_config;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Create figure
    figdwell = figure('visible',fig_vis,'Position',[100 100 1600 900]); 
    set(gcf,'InvertHardCopy','off'); % this stops white lines being plotted black      
    set(gcf,'color','w'); % makes the background colour white
    colormap(jet(256)); % to make sure the colormap is not the horrible default one
    fig_hor = nparts; % how many plots wide should it be
    fig_ver = 4; % how many plots tall should it be
    fspac = 0.01; % the spacing around the plots, on all sides
    fpadd = 0.01; % the spacing around the plots, on all sides, this takes more space than fspac though
    fmarg = 0.03; % the margins around the plots, at the edge of the figure
    fsiz = 5; % the fontsize for different texts
    flw = 1; % the line width for different plots
    
% add an annotation to the figure with some important info    
    ann_str = sprintf('Analysed: %s',datestr(now,'yyyy-mm-dd-HH-MM-SS'));
    annotation('textbox',[0, 1, 1, 0],'string',ann_str,'FontSize',fsiz,'LineStyle','none','interpreter','none');  
    annotation('textbox',[0.5, 0.98, 1, 0],'string','Positions','FontSize',10,'LineStyle','none','interpreter','none');  
    annotation('textbox',[0.5, 0.74, 1, 0],'string','Dwell time','FontSize',10,'LineStyle','none','interpreter','none');  
    annotation('textbox',[0.5, 0.5, 1, 0],'string','Time in compartments','FontSize',10,'LineStyle','none','interpreter','none');  
    % annotation('textbox',[0.5, 0.25, 1, 0],'string','Vanilla compartment','FontSize',10,'LineStyle','none','interpreter','none');  

% process data and generate figure
    for pp = 1:nparts
        part_now = part_names{pp};
        part_duration = pdata.(part_now).duration;   

        % sort out environment data
        enow = part_config.environment(pp);
        if enow == 0 % if this should be ignored, skip it
            continue
        end

        % retrieve position and spike data
        pox = double(pdata.(part_now).pox);
        poy = double(pdata.(part_now).poy);
        poc = pdata.(part_now).poc;      

        % load environment polygons
        epoly = pdata.(part_now).epoly;
        comp_poly = pdata.(part_now).comp_poly;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot showing position data and spikes
        subaxis(fig_ver,fig_hor,pp,'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
        plot(pox(poc(:,1)),poy(poc(:,1)),'k') % plot all position data inside the environment
        
        cols = lines(length(comp_poly));
        if length(comp_poly)==1
            cols = [0 0 0];
            plot(comp_poly{1}(:,1),comp_poly{1}(:,2),'Color',cols(1,:)) % plot the lemon compartment            
        else
            for ii = 2:length(comp_poly)
                plot(comp_poly{ii}(:,1),comp_poly{ii}(:,2),'Color',cols(ii,:)) % plot the lemon compartment
            end
        end
      
        daspect([1 1 1])
        axis off
        axis xy
        axis([min(epoly(:,1))-2 max(epoly(:,1))+2 min(epoly(:,2))-2 max(epoly(:,2))+2])
        title(sprintf('time = %.2fs',part_duration),'FontSize',fsiz)    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot showing dwell time map for each environment
        subaxis(fig_ver,fig_hor,pp+(nparts),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;

        % Dwell time map
        map_limits = [min(epoly(:,1))-5 max(epoly(:,1))+5; min(epoly(:,2))-5 max(epoly(:,2))+5]; 
        [dwellmap,~] = mapDATA_v3(pox(poc(:,1)),poy(poc(:,1)),map_limits,pdata.config.map_padd,pdata.config.bin_size);
        dwellmap = dwellmap .* (1/50);
        dwellmap = imgaussfilt(dwellmap,pdata.config.map_sigma);    
        im = imagesc(dwellmap);
        set(im,'alphadata',logical(dwellmap));
        daspect([1 1 1])
        axis xy off
        set(gca,'LineWidth',flw,'layer','top','FontSize',fsiz); 
        title(sprintf('%.2fs (%.2f mins)',part_duration,part_duration/60),'FontSize',6);  
        ax = axis;
%         tt = text(-1,ax(4),sprintf('%c: %.2f (s), %c: %.2f (s), %c: %.2f (s)',char(708),nanmax(dwellmap(:)),char(181),nanmean(dwellmap(:)),char(709),nanmin(dwellmap(:))),'FontSize',fsiz);
%         set(tt,'rotation',90);    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot showing bar graph of time in each compartment
        subaxis(fig_ver,fig_hor,pp+(nparts*2),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
            ax = gca;
            ax.FontSize = fsiz;
            
            if length(comp_poly)==1
                ctime = sum(poc(:,1))*(1/50); % the amount of time spent in lemon compartment = the number of points in position compartment index (poc) that equal 1 (lemon)
                b = bar(1,ctime);
                b.FaceColor = 'flat';
                b.CData(1,:) = cols(1,:); 
                ax.XLim = [.5 2.5];
                
            else
                ctimes = NaN(length(1:length(comp_poly)),1);
                for ii = 1:length(comp_poly)
                    ntime = sum(poc(:,ii))*(1/50); % the amount of time spent in lemon compartment = the number of points in position compartment index (poc) that equal 1 (lemon)
                    ctimes(ii) = ntime;
                end

                b = bar(2:length(comp_poly),ctimes(2:end));
                b.FaceColor = 'flat';
                for ii = 2:length(cols(:,1))
                    b.CData(ii-1,:) = cols(ii,:);            
                end  
                ax.XLim = [1.5 length(cols(:,1))+.5];
            end

            xlabel('Compartment')
            ylabel('Time (s)');
            axis square
            box off
    end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Save the figure    
    figfile = [pwd '\klustest\' pdata.combined_name '\figures\'];
    [~,~,~] = mkdir(figfile);
    print(figdwell,'-dpng','-r150',[figfile 'figCOMP1_dwell.png'])
    close(figdwell);                                          




    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    