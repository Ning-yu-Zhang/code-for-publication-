function figCONT2(pdata,sdata,uci,fig_vis)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   This function takes an sdata structure, a cell identifier and generates a figure for the context box experiment
%   figCONT2(sdata,uci,fig_vis,save_fig)
%
%%%%%%%% Inputs
%   sdata = sdata structure from context box function
%   uci = unique cell identifier
%   fig_vis = (optional), 'on' to show figures, 'off' to hide figures, default is 'off'
%   save_fig = (optional), 1 to save figures in .fig files, 0 otherwise, default is 0
%
%%%%%%%% Comments
%   04/07/17 created to contain all of this figure code
%   25/07/17 fixed orientation problem, fixed scaling problem from variable pixel ratio
%   � Roddy Grieves: rmgrieves@gmail.com
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initial variables
    if ~exist('fig_vis','var') || isempty(fig_vis)
        fig_vis = 'off';
    end

    part_names = table2cell(pdata.part_config(:,2))'; % the names you want the outputs to be saved as, these cannot start with a number: i.e. 'session1'
    nparts = length(part_names);
    part_config = pdata.part_config;

    % figure settings
    cring = 0; % set to 1 to plot the coloured ring around polar plots
    hd_width = 2; % line width of hd line
    ri_width = 4; % line width of coloured ring

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Create figure
    figpoly = figure('visible',fig_vis,'Position',[100 100 1600 900]); 
    set(gcf,'InvertHardCopy','off'); % this stops white lines being plotted black      
    set(gcf,'color','w'); % makes the background colour white
    colormap(jet(256)); % to make sure the colormap is not the horrible default one
    fig_hor = nparts; % how many plots wide should it be
    fig_ver = 7; % how many plots tall should it be
    fspac = 0.01; % the spacing around the plots, on all sides
    fpadd = 0.01; % the spacing around the plots, on all sides, this takes more space than fspac though
    fmarg = 0.03; % the margins around the plots, at the edge of the figure
    fsiz = 5; % the fontsize for different texts
    flw = 1; % the line width for different plots
    % add an annotation to the figure with some important info    
    ann_str = sprintf('Cell: %s, Analysed: %s',uci,datestr(now,'yyyy-mm-dd-HH-MM-SS'));
    annotation('textbox',[0, 1, 1, 0],'string',ann_str,'FontSize',fsiz,'LineStyle','none','interpreter','none');  


    % process data and generate figure
    c_rotated = 0;
    cmap = contmap(); % get custom colormap
    cmap_plot = contmap();
    for pp = 1:nparts
        
%% sort out environment data
        % I reuse a lot of the naming conventions from the parent code, this is to try and make it as understandable as possible
        % For instance enow and rnow etc are the same as before
        part_now = part_names{pp};

        % sort out environment data
        enow = part_config.environment(pp);
%         if enow == 0 % if this should be ignored, skip it
%             continue
%         end   
    
%% retrieve position and spike data
        % an exception may be that usually I use pox to mean all position data and use ppox for a part's position data
        % however, here I have used pox instead because its name is shorter and easier to use, so what? its my code, I can do what I want!
        % retrieve position and spike data
        pox = double(pdata.(part_now).pox);
        poy = double(pdata.(part_now).poy);
        poh = double(pdata.(part_now).poh);        
        poc = pdata.(part_now).poc;      
        spx = pdata.pox(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)});
        spy = pdata.poy(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)});
        sph = pdata.poh(sdata.spike_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)}); 
        spc = sdata.compartment_index{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)};
        
%% load environment polygons
        % remember that epoly is the entire environment, lpoly is the lemon compartment, vpoly is the vanilla compartment   
        epoly = pdata.(part_now).epoly;
        comp_poly = pdata.(part_now).comp_poly; 
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot showing layout of environment 
        subaxis(fig_ver,fig_hor,pp,'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
            plot(epoly(:,1),epoly(:,2),'b') % plot the lemon compartment  
            ename = pdata.part_config.enames{pp};
            rnow = pdata.part_config.rotation(pp);              
            title(sprintf('%s - %d',ename,rnow),'FontSize',fsiz)    

            cols = [0 0 0; 1 1 0;1 1 0;.5 .5 .5;.5 .5 .5];
            for i = 1:length(comp_poly)
                pnow = comp_poly{i};
                patch(pnow(:,1),pnow(:,2),cols(i,:),'FaceAlpha',.5,'EdgeAlpha',0);
                text(nanmean(pnow(:,1)),nanmean(pnow(:,2)),num2str(i-1),'FontSize',8,'HorizontalAlignment','center');
            end

            daspect([1 1 1])
            axis off xy
            axis([min(epoly(:,1))-2 max(epoly(:,1))+2 min(epoly(:,2))-2 max(epoly(:,2))+2])    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot showing polar plot for all data (inside the environment)  
        subaxis(fig_ver,fig_hor,pp+(nparts*2),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;

            %% retrieve HD analyses    
            % these are the data that were made inside that awkward cell array loop
            % it is fine here though, because I know the names that were stored in nindx (like 'whole') I can
            % just reference straight into the structure and get the data back (like 'sdata.(uci).(part_now).whole_hd')
            hdata = sdata.compartment_hd_maps{strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now)};
            ai = linspace(0,2*pi,pdata.conset.hd_bins)'; % angles for binning, I take n bins between 0 and 2pi where n = conset.hd_bins
            ai = ai(:); % you will see me do this a lot, it is just to make sure the variable is a vertical column vector rather than a horizontal one

            hd1 = hdata(1,:,1); % this is the session HD (occupancy)
            hd2 = hdata(2,:,1); % this is the cell HD
            hd3 = hdata(3,:,1); % this is the cell's firing rate (hd1 / hd2)
            rv = sdata.compartment_hd_rayleigh(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1);
            mx2 = sdata.compartment_hd_max(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1); % the angle of the peak firing rate in radians I think
            mn2 = sdata.compartment_hd_mean(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1); % the circular mean firing rate angle
            sd2 = sdata.compartment_hd_sd(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),1); % the circular standard deviation of this mean

            % retrieve data        
            if strcmp(enow,{'cbox','qbox'})
                if ~isempty(mx2) && ~isnan(mx2) && ~c_rotated
                    cmap = circshift(cmap,round(mx2),1);
                    cmap_plot = cmap;
                    c_rotated = 1;
                    c_rot_ang = rnow;
                elseif c_rotated
                    ramount = rad2deg(angdiff(deg2rad(rnow),deg2rad(c_rot_ang)));
                    cmap_plot = circshift(cmap,-ramount,1);                
                end            
            else
                if ~isempty(mx2) && ~isnan(mx2)
                    cmap_plot = circshift(contmap,round(mx2),1);
                end
            end

            % polar plot
            mmp = mmpolar(ai,hd1,'k',ai,hd3,'b','FontSize',fsiz,'Border','off','Grid','on','RGridVisible','off','RTickVisible','off','TTickDelta',90,'RTickLabelVisible','off','TTickLabelVisible','on');
            set(mmp(1),'LineWidth',0.1);  
            set(mmp(1),'Color',[0.5 0.5 0.5]);      
            hold on

            % coloured frate line
            xp = get(mmp(2),'XData');
            yp = get(mmp(2),'YData');
            xp = [xp' xp'];
            yp = [yp' yp'];
            zp = zeros(size(xp));
            cp = [ai ai];
            hs = surf(xp,yp,zp,cp,'EdgeColor','interp','FaceColor','none','Marker','none','LineWidth',hd_width);

            % text
            title(sprintf('r: %.2f, %c: %.2f, %c: %.2f, %s: %.2f',rv,char(708),mx2,char(956),mn2,char(963),sd2),'FontSize',fsiz,'FontWeight','normal');
            ylabel(sprintf('%d spikes (%.1fHz)',sum(spc(:,1)),sum(spc(:,1))/(sum(poc(:,1))*(1/50))),'FontSize',fsiz);             
            colormap(gca,cmap_plot);
            axis off square
            p1 = get(gca,'Position');
            a1 = axis;
            axis off

            if cring && strcmp(enow,{'cbox','qbox'})
                % second axis for coloured ring
                subaxis(fig_ver,fig_hor,pp+(nparts*2),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
                as = (1:2:360)';
                pnow = [1.*cos(as.*(pi/180)), 1.*sin(as.*(pi/180))];
                xp = pnow(:,1);
                yp = pnow(:,2);
                scatter(xp,yp,ri_width,as,'filled')   
                colormap(gca,cmap_plot);
                hold on;
                set(gca,'Color','none')
                axis off square
                set(gca,'Position',p1)
                axis(a1);
                axis off
            end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plot showing position data and spikes
        subaxis(fig_ver,fig_hor,pp+(nparts),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
            % plot all position data inside the environment in transparent grey
            line(pox(poc(:,1)),poy(poc(:,1)),'Color',[0.5 0.5 0.5 0.5]) 

            % plot all the spikes in the environment, coloured according to HD
            scatter(spx(spc(:,1)),spy(spc(:,1)),15,sph(spc(:,1)),'filled');

            % plot the environment outline
            plot(epoly(:,1),epoly(:,2),'b') % plot the lemon compartment
            daspect([1 1 1])
            axis off xy
            axis([min(epoly(:,1))-2 max(epoly(:,1))+2 min(epoly(:,2))-2 max(epoly(:,2))+2])
            title(sprintf('%d spikes',sum(spc(:,1))),'FontSize',fsiz,'FontWeight','normal')    
            colormap(gca,cmap_plot); % use the same colormap as the whole environment polar plot

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% plots showing polar plots for each compartment
        if strcmp(enow,{'cbox','qbox'})
            for ii = 2:length(comp_poly) % for every sub compartment
            subaxis(fig_ver,fig_hor,pp+(nparts*(ii+1)),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;    
                % retrieve data        
                hd1 = hdata(1,:,ii); % this is the session HD (occupancy)
                hd2 = hdata(2,:,ii); % this is the cell HD
                hd3 = hdata(3,:,ii); % this is the cell's firing rate (hd1 / hd2)
                rv = sdata.compartment_hd_rayleigh(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),2);
                mx2 = sdata.compartment_hd_max(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),2); % the angle of the peak firing rate in radians I think
                mn2 = sdata.compartment_hd_mean(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),2); % the circular mean firing rate angle
                sd2 = sdata.compartment_hd_sd(strcmp(sdata.uci,uci) & strcmp(sdata.part,part_now),2); % the circular standard deviation of this mean

                % polar plot
                mmp = mmpolar(ai,hd1,'k',ai,hd3,'b','FontSize',fsiz,'Border','off','Grid','on','RGridVisible','off','RTickVisible','off','TTickDelta',90,'RTickLabelVisible','off','TTickLabelVisible','on');
                set(mmp(1),'LineWidth',0.1);  
                set(mmp(1),'Color',[0.5 0.5 0.5]);      
                hold on 

                % coloured frate line
                xp = get(mmp(2),'XData');
                yp = get(mmp(2),'YData');
                xp = [xp' xp'];
                yp = [yp' yp'];
                zp = zeros(size(xp));
                cp = [ai ai];
                hs = surf(xp,yp,zp,cp,'EdgeColor','interp','FaceColor','none','Marker','none','LineWidth',hd_width);
            
                % text
                title(sprintf('r: %.2f, %c: %.2f, %c: %.2f, %s: %.2f',rv,char(708),mx2,char(956),mn2,char(963),sd2),'FontSize',fsiz,'FontWeight','normal');
                ylabel(sprintf('%d spikes (%.1fHz)',sum(spc(:,1)),sum(spc(:,1))/(sum(poc(:,1))*(1/50))),'FontSize',fsiz);             
                colormap(gca,cmap_plot);
                axis off square
                p1 = get(gca,'Position');
                a1 = axis;
                axis off
            
                if cring
                    % second axis for coloured ring
                    subaxis(fig_ver,fig_hor,pp+(nparts*3),'Spacing',fspac,'Padding',fpadd,'Margin',fmarg,'Holdaxis'); hold on;
                    as = (1:2:360)';
                    pnow = [1.*cos(as.*(pi/180)), 1.*sin(as.*(pi/180))];
                    xp = pnow(:,1);
                    yp = pnow(:,2);
                    scatter(xp,yp,ri_width,as,'filled')   
                    colormap(gca,cmap_plot);
                    hold on;
                    set(gca,'Color','none')
                    axis off square
                    set(gca,'Position',p1)
                    axis(a1);
                    axis off
                end            
            end
        end
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Save the figure    
figfile = [pwd '\klustest\' pdata.combined_name '\figures\'];
[~,~,~] = mkdir(figfile);
print(figpoly,'-dpng','-r150',[figfile uci '_contest2.png'])
close(figpoly);                                          





































