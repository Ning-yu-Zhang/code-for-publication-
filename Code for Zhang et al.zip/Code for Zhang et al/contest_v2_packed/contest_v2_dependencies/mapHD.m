function [rawdwellmap,HDCurveSmooth,r,r2,r4,peakFR,mxPFD,width,DIC,KLD,jpperc] = mapHD(ppoh,psph,config)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HISTORY:
% version 1.0.0, Release 11/04/19 Initial release, created to contain this code instead of klustest
% Author: Roddy Grieves
% 
% version 2.0.0 22/03/2020 Ningyu changed the original function to new package of HD analysis

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% FUNCTION BODY
    % Head direction analysis
  % angles for binning
    ai = linspace(0,359,config.hd_bins); % angles for binning
    ai = ai + 1; 
    rawdwellmap = hist(ppoh,ai).*(1/50);
    
    % smoothing - 5 point window 
    smoothkernel = gausswin(config.hd_boxcar);
    smoothkernel = smoothkernel/sum(smoothkernel);
    

    switch config.hd_type
        case {'density'}
            % Create a firing rate by head direction map using a kernel smoothed density estimate approach
            % Use a head direction dwell map if one was provided, or create it if not
            if ~exist('dwellmap','var') || isempty(dwellmap) || all(isnan(dwellmap(:)))
                hd_s = deg2rad(ppoh); % session head direction in radians
                [hd1] = circ_ksdensity(hd_s,ai,[],config.hd_sigma); % the session head direction       
                dwellmap = hd1 .* (1/50); % convert session HD to time 
            end

            % Calculate the kernel smoothed spike map and then the firing rate map
            [spikemap] = circ_ksdensity(hd_c,ai,[],config.hd_sigma); % the cell's head direction
            ratemap = spikemap ./ dwellmap; % calculate HD firing rate

            % head direction analyses
            hd3n = ratemap ./ max(ratemap); % normalise cell hd
            hd3n = hd3n(:);            
            r = circ_r(ai,hd3n(:)); % rayleigh vector length
            mx = rad2deg(ai(hd3n == max(hd3n))); % preferred angle (location of max frate)
            mn = rad2deg(circ_mean(ai,hd3n)); % mean angle
            sd = rad2deg(circ_std(ai,hd3n)); % std deviation angle
            
        case {'histogram'}
            % Create a firing rate by head direction map using a straight histogram approach
            HDTuning = hist(psph,ai)./rawdwellmap;
            HDTuning(isnan(HDTuning)) = 0; % replace NaNs with 0s to fix the PFD problem.
            HDTuningConcat = [HDTuning HDTuning HDTuning]; %pad HD tuning curve for smoothing
            HDCurveSmooth = imfilter(HDTuningConcat,smoothkernel','circular','same');
            clear HDTuningConcat;
            HDCurveSmooth = HDCurveSmooth(length(HDTuning)+1:2*length(HDTuning));  
            peakFR = max(HDTuning);
            mxPFD = ai(HDTuning == peakFR);% cell's PFD
            mxPFD = mxPFD(1);
            r = circ_r((ai*pi/180)',HDCurveSmooth',6*pi/180);% rayleigh vector length
            width = 2*circ_std((ai*pi/180)',HDCurveSmooth',6*pi/180);
            
            %% Angle doubling procedure - flip cells 
            dualhd = psph*2;%double direction for each spike 
            dualhd (dualhd >= 360) = dualhd(dualhd >=360)- 360; %convert angle > 2pi to be bounded within 2pi
            psph2 = dualhd;
            HDTuning2 = hist(psph2,ai)./rawdwellmap;
            HDTuning2(isnan(HDTuning2)) = 0; % replace NaNs with 0s to fix the PFD problem.
            HDTuningConcat2 = [HDTuning2 HDTuning2 HDTuning2]; %pad HD tuning curve for smoothing
            HDCurveSmooth2 = imfilter(HDTuningConcat2,smoothkernel','circular');
            clear HDTuningConcat2;
            HDCurveSmooth2 = HDCurveSmooth2(length(HDTuning2)+1:2*length(HDTuning2));
            r2 = circ_r((ai*pi/180)',HDCurveSmooth2',6*pi/180);
            
            %%Angle quadrupling procedure - for clover cells 
            dualhd2 = psph2*2;%double direction for each spike 
            dualhd2 (dualhd2 >= 360) = dualhd2(dualhd2 >=360)- 360; %convert angle > 2pi to be bounded within 2pi
            psph4 = dualhd2;
            HDTuning4 = hist(psph4,ai)./rawdwellmap;
            HDTuning4(isnan(HDTuning4)) = 0; % replace NaNs with 0s to fix the PFD problem.
            HDTuningConcat4 = [HDTuning4 HDTuning4 HDTuning4]; %pad HD tuning curve for smoothing
            HDCurveSmooth4 = imfilter(HDTuningConcat4,smoothkernel','circular');
            clear HDTuningConcat4;
            HDCurveSmooth4 = HDCurveSmooth4(length(HDTuning4)+1:2*length(HDTuning4));
            r4 = circ_r((ai*pi/180)',HDCurveSmooth4',6*pi/180);
            

            %% Estimating HD spatial information from tuning curves
           % Following Skaggs et al., 1993
           % Adrien Peyrache 2017 | peyrachelab.com | github.com/PeyracheLab
           % Here there's no smooth of data - a msg conveying one bit of
           % info is a code that reliably inform about one in two states 
           % whenever the cell fires one spike, it transmits with absolute
           % certainty the heading of the animal 
            N = size(psph,1); % number of spikes 
            T = size(ppoh,1).*(1/50);% length of recording 
            fr = N/T; % Averaging firing rate
            histAng = hist(deg2rad(ppoh),config.hd_bins);%% hd1 before converting to time 
            Px = histAng./sum(histAng); % probability of occupancy
            histAng = histAng .*(1/50);
            spkPerAng = hist(deg2rad(psph),config.hd_bins);%% hd2 
            hdTuning = spkPerAng./histAng; %% hd3 
            logTerm = log2(hdTuning/fr);
            %Correct for undefiend values 
            logTerm(hdTuning==0) = 0;
            I = hdTuning * (logTerm.*Px)' ; %information rate is (bit/sec)
            %Divide by firing rate to obtain information per spike 
            DIC = I/fr; %bit/spk % directional information content 

            %%compute the Kullback-Leibler divergence(relative entropy)- vs. uniform distribution 
            %KLD analysis 
            x = (1:60);
            hdrfit = HDCurveSmooth./nansum(HDCurveSmooth);% probability distribution 
            uni = ones(60,1)';
            unifit = uni./sum(uni); %% create a uniform prob distribution
            KLD = kldiv(x,hdrfit,unifit); 
           
            %% Check for artefacts 
            d=diff(ppoh); %take a window of 20ms - impossible for a rat to turn around or at angles larger than - let's say 60 degrees for now 
            pos_ind = (abs(d)>60 & abs(d)<300); 
            [row jump] = find(pos_ind);
            jpperc = length(d(row))/length(d)*100; %% in percentage 
            
       
    end







