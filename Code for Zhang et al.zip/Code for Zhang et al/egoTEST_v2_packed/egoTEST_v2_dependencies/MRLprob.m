function [p,p99,mrldist,nshuff,shuffled_rate_maps] = MRLprob(pot,spt,MRL,ego_adata,angs,distance_bin_edge,angle_bin_edge,ego_dmap_smoo,smoo)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% DESCRIPTION
%FUNCTION  short descr.
% long descr.
%
% USAGE:
%         [out] = template(in,in2)
%
% INPUT:
%         in - input 1
%         in2 - input 2
%
% OUTPUT:
%    p - output
%
% EXAMPLES:
%
% See also: FUNCTION2 FUNCTION3

% HISTORY:
% version 1.0.0, Release 00/00/00 Initial release
%
% Author: Roddy Grieves
% UCL, 26 Bedford Way
% eMail: r.grieves@ucl.ac.uk
% Copyright 2019 Roddy Grieves

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% INPUT ARGUMENTS CHECK
% deal with initial variables
    nshuff = 100;

%% ##################################### Heading 2
%% #################### Heading 3
%% Heading 4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% FUNCTION BODY
    spts = shiftSTRAIN(spt,'mint',min(pot),'maxt',max(pot),'shuffles',nshuff,'minadd',30);
    mrldist = NaN(size(spts,2),1);
    a = deg2rad(histcents(angle_bin_edge)');
    loopout = looper(nshuff);
    shuffled_rate_maps = cell(nshuff,1);
    for ss = 1:nshuff
        sindx_now = knnsearch(pot(:),spts(:,ss));

        % retrieve windows from data that correspond to spikes
        ego_filt_now = ego_adata(sindx_now,:);
        angs_filt_now = angs(sindx_now,:);
        ego_smap_now = histcounts2(ego_filt_now(:),angs_filt_now(:),distance_bin_edge,angle_bin_edge);
        ego_rmap_now = imgaussfilt(ego_smap_now,smoo,'FilterSize',[5 5],'Padding','circular') ./ ego_dmap_smoo;
        shuffled_rate_maps{ss} = ego_rmap_now;
        
        % generate egocentric ratemap and recalculate MRL
        w = sum(ego_rmap_now,1);
        MR_now = sum(w.*exp(1i*a),2) ./ numel(ego_rmap_now);
        MRL_now = abs(MR_now);            
        mrldist(ss,1) = MRL_now;
        loopout = looper(loopout);
    end
    p99 = prctile(mrldist(:),99);
    p = sum(mrldist>MRL) ./ nshuff;
    if ~p
        p = 1/nshuff;
    end








































