function bndsok = bssbndsok(bnds)
% BSSBNDSOK - Check the bounds of a B-spline series data structure for
%             validity.
%
% INPUTS:
%
%    bnds:
%       The lower and upper bounds for the estimation interval over which
%       the bspline series is to be created for evaluation. This is an NDIM
%       by 2 matrix, specifying the minimum and maximum values used to
%       create the B-spline series partition for each dimension.
%
%       NDIM must be 1, 2, or 3. (not currently checked)
%
%       The BNDS variable must:
%
%         be nonempty
%         be numeric
%         be an NDIM by 2 matrix
%         and have bnds(i,1) < bnds(i,2),  i = 1:NDIM
%
% OUTPUTS:
%
%   bndsok:
%      A logical flag indicating whether BNDS passed (1) or failed (0)
%      its validation tests.
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

%
% Define an initial value that is false.
%
bndsok = 0;

%
% Begin the testing with nonempty and numeric.
%
if ( isempty(bnds) )
   error('The B-spline series estimation bounds were empty.');
end

if ( ~isnumeric(bnds) )
   error('The B-spline series estimation bounds were not numeric.');
end

%
% At this point, we know that BNDS is nonempty, and numeric.
%
%
sz_bnds = size(bnds);
   
if ( sz_bnds(2) ~= 2 )
   error('The number of columns in the B-spline series estimation bounds was not equal to 2.');
end
   
ndim_b = sz_bnds(1);
%if ( ndim_b < 1 || ndim_b > 3 )
%   error('The number of dimensions used for the B-spline series must be 1, 2, or 3, and a value of %d was found for the estimation bounds.',ndim_b);
%end

%
% Check bounds for validity: bnds(i,1) < bnds(i,2), i=1:NDIM.
%
width     = bnds(:,2) - bnds(:,1);
row_ids   = (1:ndim_b)';
width_nok = width <= 0;

if ( any(width_nok) )
   error('The estimation bounds for the B-Spline series were not valid for row %d: (%g , %g).\n', ...
   [row_ids(width_nok) bnds(width_nok,1) bnds(width_nok,2)]');
end

%
% The validation tests were passed, set output value to true.
%
bndsok = 1;

