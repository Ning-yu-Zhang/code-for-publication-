function partition = bsscreatepartition(bnds,n,m)
% BSSCREATEPARTITION - Create the partition array for the B-spline series.
%
% INPUTS:
%
%    bnds:
%       The lower and upper bounds for the estimation interval over which
%       the bspline series is to be created for evaluation.
%
%    n:
%       The nominal partition size or the number of subintervals to
%       use for the partition in each dimension. The partition size for
%       each dimension does NOT include the extra subintervals that are
%       created based on the order of the B-splines that are used.
%
%    m:
%       The order of the bsplines to be used. This must be an integer scalar
%       value greater than zero (M>=1).
%
%    All inputs are assumed to be of the correct type and shape. No error
%    checking is performed in this function.
%
% OUTPUTS:
%
%
%    partition:
%       The partition array containing fields X, N, NPART, and H.
%
%       The fields represent the partition of the estimation interval for
%       each dimension, with X defining the boundary points for the
%       partition subintervals, N defining the nominal partition size,
%       NPART defining the number of boundary points, and H defining the
%       width of the subintervals for each dimension.

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

%
% Compute the partition. 
%
ndim      = size(n,1);
width     = bnds(:,2) - bnds(:,1);
h         = width./n;
npart     = n + m;
npmax     = max(npart);
partition = struct('x',[],'n',[],'npart',[],'h',[]);

partition.n     = n;
partition.npart = npart;
partition.h     = h;
partition.x     = nan(npmax,ndim);

for i = 1:ndim
   partition.x(1:npart(i),i) = linspace(bnds(i,1)-h(i)*(m-1), bnds(i,2), npart(i))';
end
