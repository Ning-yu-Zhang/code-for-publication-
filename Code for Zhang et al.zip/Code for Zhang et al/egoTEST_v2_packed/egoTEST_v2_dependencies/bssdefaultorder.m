function m = bssdefaultorder()
%BSSDEFAULTORDER B-Spline basis function default order, currently 4.
%
%         BSSDEFAULTORDER returns the current default order used by the
%         B-Spline functions FBSPLINE(X) and CBSPLINE(X). If the
%         global variable 'BSplineOrder' is not defined in the 
%         base workspace or in the B-spline workspace by the
%         function SETBSORD(M), the value returned by this function
%         is used. If the global variable 'BSplineOrder' is defined
%         in the base workspace or in the B-Spline workspace that
%         value overrids the default value defined here.
%
%         The order of the B-Spline basis function must be a positive
%         integer, m > 0. The order of the B-Spline is one greater
%         than the order of the polynomial pieces generated, i.e.,
%
%            m = 1 -> Constant functions on each subinterval.
%            m = 2 -> Linear functions on each subinterval.
%            m = 3 -> Quadratic functions on each subinterval.
%            m = 4 -> Cubic functions on each subinterval.
%            ...
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

m = 4;
