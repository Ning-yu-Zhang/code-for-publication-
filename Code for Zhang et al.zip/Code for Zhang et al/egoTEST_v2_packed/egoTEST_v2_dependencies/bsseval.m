function [y,bss_out] = bsseval(x, bss, evalfun, zerotol)
%BSSEVAL  Evaluate the B-Spline series at x.
%
% INPUTS:
%
%    x:
%       The data to be used for evaluating the B-Spline series. This is an 
%       NPOINTS by NDIM matrix with the rows representing the points.
%
%       This value may be empty if a gridded interpolant is being created.
%       In this situation the output Y will be assigned an empty value.
%       This feature allows the creation of a gridded interpolant without
%       the need to evaluate it.
%
%    bss:
%       The B-Spline series data structure containing the series to be used
%       for evaluation.
%
%    evalfun:
%       The probability function that is to be evaluated.
%
%       If the B-Spline series represents a probability density function,
%       the following output functions are available 'pdf', 'cdf', 'icdf',
%       'survivor', 'cumhazard'. If no evaluation function is specified the
%       B-Spline series is simply evaluated without transformations. An
%       evaluation function value of 'bss' (default) is also allowed, and
%       indicates that the B-spline series is simply to be evaluated.
%
%       Allowed evaluation functions.
%
%          bss      : Evaluate the B-spline series (default)
%
%        If the B-Spline series represents a probability density function:
%
%          pdf      : The probability density function, f(x)
%          cdf      : The cumulative distribution function, F(x)
%          icdf     : The inverse cumulative distribution function,
%                     F^(-1)(p)
%          survivor : The survivor function, S(x) = 1-F(x)
%          cumhazard: The cumulative hazard function,
%                     -log(1-F(x)) = -log(S(x))
%
%       The evalution functions 'icdf' and 'cumhazard' are only available
%       for 1-dimensional distributions. The 'pdf','cdf', and 'survivor'
%       evaluation functions are available for all dimensions.
%
%    zerotol:
%
%       A zero tolerance for finding flat spots in the CDF when computing
%       the ICDF. It is also used to determine a minimal support interval
%       for the CDF for interpolation of the ICDF. If a value is not
%       supplied a default value of sqrt(eps) is used. A value of zero is
%       not recommended. A nearly exact zero tolerance may be specified by
%       using the string value 'exact', indicating that a zero tolerance of
%       2048*eps will be used. The string value 'default' will use the
%       default value of sqrt(eps). Large values of the zero tolerance may
%       give inaccurate or incorrect results.
%
%       The zero tolerance is only used for the 1-dimensional 'icdf'
%       evaluation function.
%
% OUTPUTS:
%
%    y:
%       The values for the B-Spline series evaluated at x.
%
%       If the B-Spline series represents a probability density function
%       and one of the allowed functions is specified, then the output is
%       an approximation of the desired function based on the probability
%       density function represented by the B-Spline series.
%
%    bss_out:
%       If present, this output argument causes a gridded interpolant to be
%       produced and stored in the output B-spline series data structure.
%       The gridded interpolant may be used for fast approximate evaluation
%       of the function represented by the B-spline series.
%
%       Three gridded interpolant functions are allowed depending on the
%       evaluation function:
%
%          bss - The B-spline series. This is the default if no evaluation
%                function is specified.
%
%          pdf - The probability density function.
%
%          cdf - The cumulative distribution function.
%
%       Using any other evaluation function with this output argument
%       present is an error.
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Modified: 2016-03-12
% Author : Kevin R. Gehringer
%
%   Several enhancements were made to improve the performance:
%
%   1) Replaced outer products with vectors of ones used to replicate data
%      with calls to REPMAT. Since REPMAT is now a built-in function it is
%      significantly faster than using the outer product to do replication.
%   2) Removed unnecessary preallocation of the output values.
%   3) Removed unnecessary reshaping for B-splines of order 1.
%   4) Changed the matrix orientation from m by n to n by m, where m is the
%      B-spline order and n is the total number of evaluation points
%      specified by the input X.
%   5) Removed unnecessary temporary variables.
%   6) An empty value for X is allowed if NARGOUT == 2. In this case y will
%      be assigned an empty value for output.
%
%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

%
% We gotta have a B-spline series structure.
%
if ( ~exist('bss','var') )
   error('The B-spline series data structure was not provided.');
end

if ( isempty(bss) )
   error('The B-spline series data structure was empty.');
end

%
% Check B-Spline series for validity.
%
if ( bss.ndim < 1 )
   error('The number of dimensions must be at least 1 and a value of %d was found in the B-spline series structure.',bss.ndim);
end

%
% We gotta have the data array X.
%
% Check data for validity. The data must:
%   exist
%   be nonempty unless nargout == 2
%   be numeric
%   be an NDATA by NDIM matrix
%
if ( ~exist('x','var') )
   error('The evaluation points array was not supplied.');
end

if ( isempty(x) )
    if ( nargout == 2 )
        emptyx = true;
    else
        error('The evaluation points array was empty.');
    end
else
    emptyx = false;
end

if (~emptyx )
    if ( ~isnumeric(x) )
       error('The evaluation points array was not numeric.');
    end

%
%   At this point, we know that X exists, is nonempty, and numeric.
%
%   Get the number of dimensions and check.
%
    sz_x = size(x);

    if ( length(sz_x) ~= 2 )
       error('The data array must be 2-dimensional with rows representing the data points.');
    end
   
    ndim_x = sz_x(2);
    if ( ndim_x <1 )
       error('The number of dimensions used for the data array must be at least 1 and a value of %d was found.',ndim_x);
    end

    if ( ndim_x ~= bss.ndim )
       error('Dimension mismatch: data dimension (%d) is not equal to B-spline series (%d).',ndim_x, bss.ndim);
    end
end

%
%   Check to see if an evaluation function was specified. If not, assign
%   the default.
%
if ( ~exist('evalfun','var') )
    evalfun = 'bss';
end

%
% Validate the evaluation function and zero tolerance based on the domain
% dimension. PDF, CDF, and survivor are allowed for all dimensions. If
% zerotol is also defined it is an error.
%
okfuns = {'bss'; 'pdf'; 'cdf'; 'survivor'};
if ( ~any(strcmpi(evalfun,okfuns)) )
    if ( exist('zerotol','var') )
        error('A zero tolerance is only valid with the one dimensional function ''icdf''.');
    end
end

isicdf = false;
okfuns = {'icdf'; 'cumhazard'};
if ( any(strcmpi(evalfun,okfuns)) )
    if (bss.ndim > 1)
        error('Evaluation functions ''icdf'' and ''cumhazard'' are only valid for one dimensional distributions.');
    end
%
%   We know bss.ndim == 1  and the function is 'icdf' or 'cumhazard' so:
%
%   Check to see if the evauation function is 'icdf' and a zero
%   tolerance was specified. If  the function was 'icdf' and no zero
%   tolerance was specified, assign 'default'. If the function was not
%   'icdf' and a zero tolerance was specified, signal an error.
%
    if (strcmpi(evalfun,'icdf') )
        isicdf = true;
        if ( ~exist('zerotol','var') )
            zerotol = 'default';
        end
    else
        if ( exist('zerotol','var') )
            error('The zero tolerance is only allowed for the ''icdf'' function.');
        end
    end

end

%
% The number of output arguments must be 1 or 2, anything else is an error.
%
if ( nargout > 2 )
    error('Too many output arguments');
end

%
% Only 'bss',' pdf', and 'cdf' are allowed for gridded interpolants when
% nargout == 2.
%
if ( nargout == 2 )
    
    okfuns = {'bss';'pdf';'cdf'};
    if ( ~any(strcmpi(evalfun,okfuns)) )
        error('The evaluation function ''%s'' is not used to create a gridded interpolant.',evalfun);
    end
    [bss.(evalfun).xgrid,bss.(evalfun).ygrid,bss.(evalfun).h] = bsscreateinterpolant(bss,evalfun);
     
end
    
%
%   Select the right case and compute the values, unless X is empty.
%
if ( emptyx )
    
    y = [];
    
else
    
    switch( bss.ndim )
       case 1
           if ( isicdf )
               y = bsseval1d(x,bss,evalfun,zerotol);
           else
               y = bsseval1d(x,bss,evalfun);
           end
       case 2
           y = bsseval2d(x,bss,evalfun);
       case 3
           y = bsseval3d(x,bss,evalfun);
        otherwise
           y = bssevalnd(x,bss,evalfun);
    end
end

if (nargout == 2 )
    bss_out = bss;
end

