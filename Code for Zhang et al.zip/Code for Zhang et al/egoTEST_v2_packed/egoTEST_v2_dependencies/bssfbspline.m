function y = bssfbspline(x,m)
%BSSFBSPLINE Forward normalized B-Spline function, vectorized.
%
% INPUTS:
%
%    x:
%        A scalar value, column vector, or matrix of values for which
%        the value of the B-spline of order m is desired.
%
%     m:
%        The bspline order. m >= 1.
%
% OUTPUTS:
%
%    y: 
%        Output values of the bspline evaluated at x. The shape will be
%        the same as the input shape.
%
% DESCRIPTION:
%
%         BSSFBSPLINE(X,M) returns the value(s) of the normalized
%         B-Spline of order M evaluated at the points in X.
%
%         BSSFBSPLINE(X,M) > 0 for all X in (0, M) and zero
%         elsewhere, so BSSFBSPLINE is a function having compact
%         support. BSSFBSPLINE also integrates to one, i.e., it can
%         be thought of as a probability density function.
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Created: 2014-11-25
% Author : Kevin R. Gehringer
%

y = bssbasisfun( x, m );

