function bss_struct = bsspdfcheckinputs( x, bnds, n, m, bss )
% BSSCHECKINPUTS - Check inputs to the BSSPDFEST functions, returning a
%                  B-spline series structure if successful
%
%    x:
%       The data to be used for the B-Spline density estimation. This
%       must be a column oriented array with each row representing a data
%       point, X(NDATA,NDIM) in size.
%
%    bnds:
%       The lower and upper bounds of the estimation interval for each
%       dimension. This is an NDIM by 2 matrix, specifying the minimum and
%       maximum values used to create the B-spline series partition for
%       each dimension.
%
%       If empty or not present, the estimation bounds are generated from
%       the data using bsscreatebnds().
%
%    n:
%       The nominal partition size or the number of subintervals to use for
%       the partition in each dimension. The partition size for each
%       dimension does NOT include the extra subintervals that are created
%       based on the order of the B-splines that are used. This is a row or
%       column vector with NDIM elements. NDIM must be >=1.
%
%       If empty or not present, the default value obtained from the
%       function bsspartitionsize() and the number of data points is used
%       for each dimension.
%
%    m:
%       The order of the bsplines to be used. This must be an integer
%       scalar value greater than zero (M>=1).
%
%       If not present or empty, the default value is obtained from the
%       function bssdefaultorder().
%
%    bss:
%       An existing B-Spline series probability density estimate
%       that is to have more data points added to it. This allows one
%       to build a B-Spline density estimate a little bit at a time.
%
%       If this argument exists, then BNDS, N, and M are ignored and the
%       values in BSS are used.
%
% OUTPUTS:
%
%    bss_struct:
%
%       A B-Spline series data structure with the following fields.
%
%          m         - The order of the B-spline basis functions. This is a scalar
%                      value that is the same for all dimensions.
%          ndim      - The number of dimensions for the B-spline series.
%          npts      - The number of data points used to compute the coefficients.
%          bnds      - The estimation bounds for each dimension.
%          partition - The partition array containing fields X, N, NPART, and H.
%                      The fields represent the partition of the estimation interval
%                      for each dimension, with X defining the bounday points for
%                      the partition subintervals, N defining the nominal partition
%                      size, NPART defining the number of boundary points, and H
%                      defining the width of the subintervals for each dimension.
%          c         - The coefficient matrix for the B-spline series
%

%
% Copyright 2014-2018 Biometrics Northwest LLC
%

%
% Modified: 2018-02-23
% Author  : Kevin R. Gehringer
%
%     Fixed an error message that had the wron variable used for a value.
%
%     Changed 'modified' to 'Created' since there was only one entry.
%
% Created: 2016-09-14
% Author : Kevin R. Gehringer
%

%
% We gotta have the data array X.
%
% Check data for validity. The data must:
%   exist
%   be nonempty
%   be numeric
%   be an NDATA by NDIM matrix, where NDIM is 1 NDATA is the number of
%   rows.
%
if ( ~exist('x','var') )
   error('The data array was not supplied.');
end

if ( isempty(x) )
   error('The data array was empty.');
end

if ( ~isnumeric(x) )
   error('The data array was not numeric.');
end

%
% At this point, we know that X exists, is nonempty, and numeric.
%
% Get the number of dimensions and check. Only a values of 1 is valid for
% the number of columns and the array must be two dimensional.
%
sz_x = size(x);

if ( length(sz_x) ~= 2 )
   error('The data array must be N by M with rows representing the data points.');
end

npts_x = sz_x(1);
ndim_x = sz_x(2);
std_x  = std(x)';

%
% If we do not have a BSS data structure we need to create one from the
% BNDS, N, and M inputs or default values.
%

havebss = exist('bss','var');
if (havebss)
    havebss = havebss && ~isempty(bss);
end
if ( ~havebss )

    havebnds = exist('bnds','var');
    if (havebnds)
        havebnds = havebnds && ~isempty(bnds);
    end
    if ( havebnds )
        
        bssbndsok(bnds);
%
%       Check to be sure that the dimensionality of the data and the bounds
%       agree.
%
        ndim_b = size(bnds,1);
        if ( ndim_x ~= ndim_b )
            error('Dimension mismatch: data (%d) is not equal to estimation bounds (%d).',ndim_x, ndim_b);
        end
        
    else
        
        bnds   = bsscreatebnds(x);
        ndim_b = size(bnds,1);
        
    end
    
%
%  Check the number of subintervals.
%
%  Check the number of partition subintervals. At this point it may not
%  exist or it could be empty.
%
    haven = exist('n','var');
    if (haven)
        haven = haven && ~isempty(n);
    end
    if ( haven )
  
         bsspartitionsizeok(n);
   
         if ( isrow(n) )
            n = n';
         end
   
    else
        
        n = bsspartitionsize(npts_x,ndim_x);
        if ( any(std_x > 1))
            n = (1+floor((1/2)*std_x)).*n;
        end
        
    end

%
%  Check to be sure that the dimensionality of the partitions and the bounds
%  agree.
%
    ndim_n = size(n,1);
    if ( ndim_n ~= ndim_b )
       error('Dimension mismatch: estimation bounds (%d) is not equal to data and partition size (%d).',ndim_b,ndim_n);
    end

%
%  Check the B-Spline order.
%
    havem = exist('m','var');
    if (havem)
        havem = havem && ~isempty(m);
    end
    if ( havem )
        
        bssorderok(m);
        
    else
        
        m = bssdefaultorder;
        
    end
    
    bss = bsscreatestruct(bnds, n, m );
    
else

%
% Check B-Spline series for validity.
%
    if ( bss.ndim < 1 )
       error('The number of dimensions must be at least 1 and a value of %d was found in the B-spline series structure.',bss.ndim);
    end

    if ( ndim_x ~= bss.ndim )
       error('Dimension mismatch: data dimension (%d) is not equal to B-spline series (%d).',ndim_x, bss.ndim);
    end

end

bss_struct = bss;
