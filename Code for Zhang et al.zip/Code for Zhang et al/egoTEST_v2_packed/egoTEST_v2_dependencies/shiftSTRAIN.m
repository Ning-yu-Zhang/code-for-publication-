function [spt2,spindx2] = shiftSTRAIN(pot,spt,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% DESCRIPTION
%shiftSTRAIN  shifts spike trains for shuffled analyses. This function
%shifts the indices of the spikes relative to the position data, so spikes
%will always be shifted in increments of the positions sampling interval.
%The benfit of this is that spikes are only shifted to possible position
%samples, whch means it works even when there are gaps in the position time
%vector, which can happen when recordings are stitched together and we want
%to shuffle across them
%
% USAGE:
%           spt2 = shiftSTRAIN(pot,spt) randomly shuffles vector of spike times spt
%           by between 20s and max(spt) minus 20s, spt_shift is the same size as spt
%
%           [spt2,spindx2] = shiftSTRAIN(___,Name,Value,...) randomly shuffles vector of spike 
%           times spt with Name-Value pairs used to control aspects of the
%           shuffle, also outputs a new vector into position data for
%           shuffled spikes
%
%           Parameters include:
%
%           'pot'          -   Vector of position timestamps, these can
%                               have gaps, i.e. where 2 recordings were
%                               stitched together
%
%           'spt'          -   Vector, of spike timestamps that correspond
%                               to pot
%
%           'spindx'       -   Optional vector, index into pot for the
%                               spike times in spt, otherwise this is
%                               calculated as knnsearch(pot,spt)
%
%           'minadd'          - Scalar, minimum time to add to shuffles, in
%                                samples not seconds, default is 100
%                                samples or 20s at 50Hz sampling rate
%
%           'maxadd'          - Scalar, maximum time to add to shuffles, in
%                                samples not seconds, default is
%                                numel(pot)-100 samples or 20s at 50Hz sampling 
%                                rate
%
% EXAMPLES:
%
%   % shuffle spikes using default values
%   spt = sort(1000.*rand(100,1)); % dummy spike times
%   spt_shift = shiftSTRAIN(spt,'mint',0,'maxt',1000);
%
%   % generate 10 spike time shuffles, minimum shift is 1s
%   spt_shift = shiftSTRAIN(spt,'mint',0,'maxt',1000,'shuffles',10,'minadd',1);
%
% See also: circshift diff rand

% HISTORY:
% version 1.0.0, Release 06/11/19 Initial release
% version 2.0.0, Release 20/08/20 Changed to shifting indices
%
% Author: Roddy Grieves
% UCL, 26 Bedford Way
% eMail: r.grieves@ucl.ac.uk
% Copyright 2019 Roddy Grieves

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% INPUT ARGUMENTS CHECK
%% Prepare default settings      
    def_minadd          = 100;        
    def_maxadd          = numel(pot);        
    
%% Parse inputs
    p = inputParser;
    addRequired(p,'pot',@(x) ~isempty(x) && ~all(isnan(x(:))) );      
    addRequired(p,'spt',@(x) ~isempty(x) && ~all(isnan(x(:))) );  
    addParameter(p,'spindx',NaN,@(x) ~isempty(x) && ~all(isnan(x(:))) )
    addParameter(p,'minadd',def_minadd,@(x) isnumeric(x) && isscalar(x)); 
    addParameter(p,'maxadd',def_maxadd,@(x) isnumeric(x) && isscalar(x));     
    parse(p,pot,spt,varargin{:});

%% Retrieve parameters 
    config = p.Results;

%% ##################################### Heading 2
%% #################### Heading 3
%% Heading 4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ################################################################# %% FUNCTION BODY
    if isempty(config.spindx) | isnan(config.spindx)
        config.spindx = knnsearch(pot,spt);
    end
    spike_diff = pot(config.spindx)-spt; % difference between each spike and its nearest position time neighbour

    shift_amount = randi([config.minadd,config.maxadd],1) .* (2*(rand(1)>.5)-1);

    spindx2 = config.spindx + shift_amount;
    max_idx = numel(pot);
    spindx2(spindx2<1) = spindx2(spindx2<1)+max_idx;
    spindx2(spindx2>max_idx) = spindx2(spindx2>max_idx)-max_idx;

    spt2 = pot(spindx2)-spike_diff;










































